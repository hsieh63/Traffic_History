runnable code for the website can be found on:
traffichistory.org

for Web Application

the Map page can be found under Services->Map
allowed inputs:
-5 digit zip code
-dropdown menu list of times
-dropdown menu list of weathers

the Directions page can be found under Services->Directions
allowed inputs:
-Textbox of starting location
-textbox of destination
-dropdown menu of times



Source code for the website can be compiled under a localhost or under an existing website.
Clearly, the easiest option is to simply go to our website, shown above. To host the code, upload
folder index.php under code to host the entire website.



for Mobile Application

The mobile system was developed in Eclipse with the Android SDK. 
To run the code, download the entire Traffic folder and open it in Eclipse with the Android SDK installed.
Select Window > AVD Manager from the Window dropdown menu.
Create a virtual device to test the code.
Select Run > Run As > Android Application from the Run dropdown menu to launch the application on the virtual device.


Once run, the functions of the application are as follows:

The Map page can be found under Report
allowed inputs:
-5 digit zip code
-dropdown menu list of times
-dropdown menu list of weathers

The submit mobile report can be found under "Sumbit"
allowed inputs
-radio button input choosing value from 1 to 5

For scripts

The scripts are written in perl. They should be run on the same machine as where the database resides.
The user authentication should be changed if the database has different authentication credentials.
Otherwise the scripts should be run autonomously.
