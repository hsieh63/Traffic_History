﻿<?php include 'header.php'; ?>
    <div align="center">
        <table style="border:1px solid black;">
            <tr>
                <td>Due dates</td>
                <td>Item</td>
            </tr>
            <tr>
                <td>01/29</td>
                <td>Proposal</td>
                <td><a href="projectProp.php" target="_blank">Project Proposal PDF</a></td>
            <tr>
                <td>02/12</td>
                <td>First report, Part 1</td>
                <td><a href="repOnePtOne.php" target="_blank">First report part one PDF</a></td>
            <tr>
                <td>02/18</td>
                <td> First report, Part 2</td>
                <td><a href="repOnePtTwo.php" target="_blank">First report part two PDF</a></td>
            <tr>
                <td>02/22</td>
                <td> First report, Full report</td>
                <td><a href="repOne.php" target="_blank">First report Full report PDF</a></td>
            <tr>
                <td>03/01</td>
                <td> Second report, Part 1</td>
                <td><a href="repTwoPtOne.php" target="_blank">Second report part one PDF</a></td>
            <tr>
                <td>03/08</td>
                <td> Second report, Part 2</td>
                <td><a href="repTwoPtTwo.php" target="_blank">Second report part two PDF</a></td>
            <tr>
                <td>03/15</td>
                <td> Second Report, Full report</td>
                <td><a href="repTwo.php" target="_blank">Second report part two PDF</a></td>
            <tr>
                <td>04/02</td>
                <td> First demo</td>
                <td>Done</td>
            <tr>
                <td>05/07</td>
                <td> Third report</td>
                <td>Not completed yet</td>
            <tr>
                <td>05/09</td>
                <td> Second demo</td>
                <td>Not completed yet</td>
            <tr>
                <td>05/11</td>
                <td> Electronic Project archive</td>
                <td>Not completed yet</td>
            </tr>
        </table>
    </div>
<?php include 'footer.php'; ?>