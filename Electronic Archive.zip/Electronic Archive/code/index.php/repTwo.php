﻿<html>
  <head>
     <title>Report Two</title>
     <script type="text/javascript" src="/scripts/pdfobject.js"></script>
     <script type="text/javascript">
      window.onload = function (){
        var myPDF = new PDFObject({ url: "/pdf/Group7_Traffic_Report2_Part3.pdf" }).embed();
      };
    </script>
  </head>
 
  <body>
    <p>It appears you don't have Adobe Reader or PDF support in this web
    browser. <a href="sample.pdf">Click here to download the PDF</a></p>
  </body>
</html>