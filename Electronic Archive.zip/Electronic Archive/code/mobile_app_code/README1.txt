The mobile system was developed in Eclipse with the Android SDK. 
To run the code, download the entire Traffic folder and open it in Eclipse with the Android SDK installed.
Select Window > AVD Manager from the Window dropdown menu.
Create a virtual device to test the code.
Select Run > Run As > Android Application from the Run dropdown menu to launch the application on the virtual device.
